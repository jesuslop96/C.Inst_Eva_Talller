Peso = float(input("Ingrese su peso en kilogramos:"))
Altura = float(input("Ingrese su altura en metros:"))

IMC = Peso / Altura**2

print("Su resultado de IMC es:" ,IMC)