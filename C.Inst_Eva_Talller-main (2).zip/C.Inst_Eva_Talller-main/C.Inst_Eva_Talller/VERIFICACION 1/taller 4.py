#•	Verifica si 'x' está entre 'y' y 'z', y si 'w' es par:
x, y, z, w = 15, 10, 20, 8

Solucion1 = y <= x <= z

Solucion2 = w % 2 == 0

print(Solucion1)
print(Solucion2)
