#•	Verifica si 'x' es negativo, 'y' es positivo, y 'z' es cero:

x, y, z = -3, 5, 0

Solucion1 = x < 0

Solucion2 = y > 0

Solucion3 = z == 0

print(Solucion1)
print(Solucion2)
print(Solucion3)